'''a = 5
print("Type of a: ", type(a))
 
b = 5.0
print("\nType of b: ", type(b))
 
c = 2 + 4j
print("\nType of c: ", type(c))
    '''

'''String1 = 'Welcome to the Python World'

print(String1)
'''

'''l = []
 
# Adding Element into list
l.append(5)
l.append(10)
print("Adding 5 and 10 in list", l)
'''

'''tup = (1, "a", "string", 1+2)
print(tup)
print(tup[1])
'''

'''i = 1
while (i < 4):
    print(i)
    i += 1
    '''
    
    
    
'''Dict = {1: 'Program', 2: 'in', 3: 'Python'}
print(Dict)
'''


'''List =['GeeksForGeeks', 'VenD', 5]
print('List[2]+2, Answer: ', end ='')
print(List[List.index(5)]+2)
'''

 
'''test_list = ['man', 'a', 'geek', 'for', 'b', 'free']
 
# printing original list
print("The original list : " + str(test_list))
,,,
'''





'''x = 3
if x == 4:
  print("Yes")
else:
  print ("No")
  '''
  
'''count = 0
while (count < 3):
    count = count + 1
    print("Niveditha")
else:
    print("In Else Block")
    '''
    
    
'''list = ["Python", "for", "program"]
for index in range(len(list)):
    print(list[index])
  '''
  
  
'''a,b,c = input("enter the three values - ").split()
avg = (int(a)+int(b)+int(c))/3
print(avg)
'''

'''age = int(input("Enter your age: "))
if age<3:
    print("Ticket free")
elif 3< age <= 10:
    print("Ticket 100")
elif 10 < age <= 50:
    print("Ticket 200")
else:
    print("Ticket 300")
    '''
    
    
    
    
'''age = input("Enter your age: ")
age = int(age)
if age >= 14:
    print("you can play this game")
else:
    print("you cannot play")
    '''
    
    
    
    
    
def greater_number(x, y):
    if x > y:
        return x
    else:
        return y
