string =    'malwmrllpl lallalwgpd paaafvnqhl cgshlvealy lvcgergffy tpktrreaed lqvgqvelgg gpgagslqpl alegslqkrg iveqcctsic slyqlenycn'
string= string.replace(" ","")
print(string)
print(string[0:24])
print(string[25:54])
print(string[55:89])
print(string[90:110])
print(len(string))

