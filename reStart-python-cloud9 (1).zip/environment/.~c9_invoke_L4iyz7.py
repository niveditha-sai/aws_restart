i = 1
n = 10
while(i <= n):
    sum