"""
num1, num2, num3 = 10 , 30 , 20
max = 0
if num1 >= num2 and num1 >= num3:
  print(num1)
elif num2 >= num1 and num2 >= num3:
  print(num2)
else:
  print(num3)
  """
  
  
"""
x = 8
if x % 2 == 0:
    print(x,"Is Even Number")
else:
    print(x, "Is Odd Number")
    
    """
    
"""x = 10
y = 50
 
temp = x
x = y
y = temp
 
print("Value of x:", x)
print("Value of y:", y)
"""




"""if("is Prime(11)") : 
    print(" true") 
else : 
    print(" false") 
        
if("is Prime(24)") : 
    print(" false") 
else :  
    print(" true") 
    """
    
"""n = 10
fact = 1
 
for i in range(1, n+1):
   fact = fact * i
 
print("The factorial of 10 is : ")
print(fact)
"""

"""string = "niveditha" 
   
 
print("Individual characters from given string:") 
   
for i in range(0, len(string)):  
    print(string[i])  
    """
    
    
"""list = [1, 3, 5, 7, 9]
  
for i in list:
    print(i)
    """
    
    
    
"""for i in range(2, 4):
  
    # Printing inside the outer loop
    # Running inner loop from 1 to 10
    for j in range(1, 11):
  
        # Printing inside the inner loop
        print(i, "*", j, "=", i*j)
    # Printing inside the outer loop
    print()
    """
    
    
"""count = 0
while (count < 5):
    count = count + 1
    print("niveditha")
    """
    
    
    
"""    # Function for nth Fibonacci number
def Fibonacci(n):
   
    # Check if input is 0 then it will
    # print incorrect input
    if n < 0:
        print("Incorrect input")
 
    # Check if n is 0
    # then it will return 0
    elif n == 0:
        return 0
 
    # Check if n is 1,2
    # it will return 1
    elif n == 1 or n == 2:
        return 1
 
    else:
        return Fibonacci(n-1) + Fibonacci(n-2)
        '''
 

    
    
   
   
x = 3
if x == 4:
  print("Yes")
else:
  print("No")
    
    
    
