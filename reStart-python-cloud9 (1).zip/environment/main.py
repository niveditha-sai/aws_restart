import user
print(user.login("Ram"))
print(user.logout("Ram"))
