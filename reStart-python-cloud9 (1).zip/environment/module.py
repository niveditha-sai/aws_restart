
'''def login(username):
    return "Welcome, " + username +  "!"
    
def logout(username):
    return "Have a nice day, " + username + "!"
    '''
    
    
    
'''import datetime
print(datetime.date.today())
print(datetime.datetime.now())
'''

'''import json

data = {
    "name" : "John",
    "age" : "24",
    "city" : "Vizag"

}
j =json.dumps(data)
print(j)
'''


'''import os
print(os.getcwd())

os.getlogin()
print(os.getlogin())
'''

'''import math
x= input("enter the value-x, ")
y=float(input("enter the value-y, "))

print(math.fabs(x))
print(math.floor(y))
print(math.ceil(y))
'''
'''import math
print(math.floor(1.1))
print(math.ceil(1.1))
'''


'''a= "hi, how are you"
print(len(a))
'''


'''a ='malwmrllpllallal wgpdpaaafvnqhlcgshlv ealylvcgergffy tpktrreaed'
print(a[0:24])
a = a.replace(" ","")
print(a)
'''

'''string= "N i v e d i t h a"
string= string.replace(" ","")
print(string)
'''

'''list1=['a','b','c','d']
print(list1[2])'''


'''import math
absolute = -5.999 
floor_test = 198.42
result1 = math.fabs(absolute) 
result2 = math.floor(floor_test)

print(result1, " is the absolute value of ", absolute) 
print(result2, " is the flow of ", floor_test)
'''

'''import json
filename = 'userName.json' 
name = ''
# Check for a history file try:
with open(filename, 'r') as r: # Load the user's name from the history file name = json.load(r)
except IOError: 
    print("First-time login")
# If the user was found in the history file, welcome them back if name != "": print("Welcome back, " + name + "!")
else: # If the history file doesn't exist, ask the user for their
    name
    name = input("Hello! What's your name? ") 
    print("Welcome, " + name + "!")
    import json
filename = 'userName.json' name = ''
# Check for a history file try:
with open(filename, 'r') as r: # Load the user's name from the history file name = json.load(r)
except IOError: print("First-time login")
# If the user was found in the history file, welcome them back if name != "": print("Welcome back, " + name + "!")
else: # If the history file doesn't exist, ask the user for their
name
name = input("Hello! What's your name? ") print("Welcome, " + name + "!")
'''

'''import math
print(math.pi)
print(math.sqrt(4))
print(math.e)
'''




    
    








    